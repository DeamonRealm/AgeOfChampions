#include <stdlib.h>
#include <stdio.h>
#include "j1Timer.h"
#include <windows.h>

#define TEST_RATE 5000
#define TESTS 100

#include "SDL/include/SDL.h"
#pragma comment( lib, "SDL/libx86/SDL2.lib" )
#pragma comment( lib, "SDL/libx86/SDL2main.lib" )

int main(int argc, char* args[])
{
	printf("============== TEST STARTED! ==============\n\n");

	//Timer to check the test rate
	j1Timer test_timer;
	
	//Variable to count the test errors
	unsigned short errors = 0;
	//Iterate tests
	for (unsigned short k = 0; k < TESTS; k++)
	{
		//Call AOCH process in the correct folder
		STARTUPINFO si = { 0 };
		PROCESS_INFORMATION pi = { 0 };
		if (!CreateProcess("C:\\Users\\ferra\\Desktop\\Age_of_Empires_II\\AoE_Project\\Release\\Age_of_Champions.exe", NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
		{
			printf("Error in test %ui call!");
			errors++;
		}
		else
		{
			printf("Process correctly started");
		}

		//This is a kind of delay
		test_timer.Start();
		while (test_timer.Read() < TEST_RATE) {};
		
		//End all the process with the same name as "Age_of_Champions"
		if (!system("taskkill /f /t /im Age_of_Champions.exe"))
		{
			printf("\n\nProcess correctly ended\n\n");
		}
		else
		{
			printf("\n\nProcces end error!\n\n");
			errors++;
		}
	}

	printf("Test ended with %ui errors");

	getchar();

	return 0;
}